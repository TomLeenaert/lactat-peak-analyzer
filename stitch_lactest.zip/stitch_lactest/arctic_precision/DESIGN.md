# Design System Specification: The Kinetic Laboratory

## 1. Overview & Creative North Star
**Creative North Star: The Kinetic Laboratory**
This design system is engineered for the intersection of extreme human performance and cold-weather precision. Moving beyond the "app" feel, the interface should mirror a high-performance sports car dashboard or professional lab equipment used in sub-zero environments. 

To achieve a "Signature Editorial" look, we break the rigid, centered grid in favor of **Intentional Asymmetry**. Key data points should feel heavy and grounded, while secondary information floats in high-contrast layers. We utilize massive typography scales and "glowing" interactive states to ensure maximum legibility for coaches operating in high-glare or low-visibility outdoor conditions.

## 2. Colors
The palette is rooted in a "void" of deep charcoal, punctuated by high-frequency neon accents that signify energy and technical accuracy.

*   **Primary Accent (`primary` - #bd9dff):** Use for core brand moments and primary actions. It represents the "energy" of the coaching experience.
*   **Secondary/Success (`secondary` - #00fdc1):** A high-visibility mint for "in-zone" performance and safety confirmation.
*   **Tertiary/Alert (`tertiary` - #ff7440):** A safety orange for critical physiological alerts or environmental warnings.

### The "No-Line" Rule
Standard 1px borders for layout sectioning are strictly prohibited. Boundaries must be defined through **Background Color Shifts**. For example:
*   Place a `surface-container-low` section against the `surface` background to define a sidebar.
*   Use `surface-container-highest` for top-level headers.
Never use a line where a tonal shift can achieve the same structural clarity.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
1.  **Base:** `surface` (#0e0e0e).
2.  **Level 1 (Sections):** `surface-container-low` (#131313).
3.  **Level 2 (Interactive Modules):** `surface-container-high` (#201f1f).
4.  **Level 3 (Priority Data):** `surface-container-highest` (#262626).

### The "Glass & Gradient" Rule
To prevent a flat, "webby" look, floating modals and navigation bars must use **Glassmorphism**. Use semi-transparent `surface-container-high` with a 20px-40px backdrop blur. 
**Signature Texture:** Use a subtle linear gradient on main CTAs from `primary_dim` (#8b4aff) to `primary` (#bd9dff) at a 135-degree angle to simulate the shimmer of technical materials.

## 3. Typography
The type system prioritizes aggressive legibility and a "Technical Editorial" aesthetic.

*   **Display & Headlines:** Using **Space Grotesk**. This font’s wide apertures and geometric construction mimic professional measuring instruments. 
    *   *Usage:* Use `display-lg` (3.5rem) for singular, high-impact metrics (e.g., Heart Rate, Velocity).
*   **Body & Titles:** Using **Inter**. Chosen for its legendary clarity at small sizes. 
    *   *Usage:* All technical specs and labels should be in `label-md` using uppercase tracking (+5%) to maintain the "Lab Equipment" vibe.

The hierarchy must be extreme. If a metric is important, it should be four times larger than its supporting label.

## 4. Elevation & Depth
In a dark, high-contrast environment, traditional drop shadows are often invisible or "muddy." We replace them with **Tonal Layering** and **Glows**.

*   **The Layering Principle:** Depth is achieved by "stacking." A `surface-container-lowest` card placed on a `surface-container-low` background creates a "sunken" precision-molded look.
*   **Ambient Shadows:** For floating elements, use a shadow color tinted with the `primary` token at 8% opacity. Blur values must be large (24px+) to create a soft, atmospheric lift.
*   **The "Ghost Border" Fallback:** If a component requires a boundary for accessibility (like an input field), use a "Ghost Border": the `outline-variant` token at 20% opacity. 
*   **Precision Glow:** Active states should utilize a 4px outer glow of the `primary` or `secondary` color, simulating a backlit LED display.

## 5. Components

### Buttons (Precision Targets)
*   **Primary:** Background: `primary_container`. Text: `on_primary_container`. Border-radius: `DEFAULT` (0.25rem). 
*   **Styling:** Use extra-large padding (`spacing-4` / 1.4rem) to ensure ease of use with gloves.
*   **States:** On `:hover` or `:active`, apply a 2px solid border of `primary` to create a "thick" tactile feedback.

### Data Cards
*   **Structure:** No borders or dividers. Separate content using `spacing-6` (2rem) of vertical white space.
*   **Nesting:** Place data within a `surface-container-high` module. Use `secondary` (Mint) for positive trend lines and `tertiary` (Orange) for negative deviations.

### Input Fields
*   **Aesthetic:** Rugged and industrial. 
*   **Style:** Use `surface-container-lowest` as the field background. On focus, the border should jump to a 2px solid `primary` with a subtle glow. This mimics "locking in" a value on a professional sensor.

### Status Chips
*   **Style:** Use `label-sm` in all caps. 
*   **Coloring:** Use `secondary_container` for "Active" and `error_container` for "Critical." These should feel like small LED indicator lights on a dashboard.

### Professional Coaching "HUD" (Heads-Up Display)
*   A specialized component for real-time tracking. Use a `full` roundedness for progress rings, but keep all other containers at `DEFAULT` (0.25rem) to maintain the "rugged/sharp" aesthetic.

## 6. Do's and Don'ts

### Do
*   **DO** use extreme typographic contrast. Make headlines massive and labels tiny but legible.
*   **DO** use `secondary` (Mint) for anything related to "Success," "In-Zone," or "Go."
*   **DO** leave significant "air" (using `spacing-10` or `spacing-12`) between major data modules to prevent cognitive overload in the field.

### Don't
*   **DON'T** use 1px solid lines for decoration. It breaks the "Precision Monolith" aesthetic.
*   **DON'T** use "Standard" grey shadows. Always tint shadows with the primary violet or background charcoal.
*   **DON'T** use rounded corners larger than `xl` (0.75rem) for main containers. The system should feel "engineered," not "soft."
*   **DON'T** crowd touch targets. In outdoor coaching, precision is lost; maintain a minimum target size of 48px.